#include "MessageBase.h"

Id MessageBase::s_nextId = 1;
