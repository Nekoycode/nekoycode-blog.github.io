#include "MessageListenerBase.h"

Id MessageListenerBase::s_nextId = 1;
